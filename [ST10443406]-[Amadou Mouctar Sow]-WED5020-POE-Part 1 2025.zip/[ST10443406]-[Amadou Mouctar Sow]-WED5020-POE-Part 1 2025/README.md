## References

1) Craiyon,(n.d.) Logo source. Available at: https://www.craiyon.com/ (Accessed: 27 March 2024).

2) Pixlr (n.d.) Logo cropping tool. Available at: https://pixlr.com/express/ (Accessed: 27 March 2024).

3) Wepik (n.d.) AI-generated background image. Available at: https://wepik.com/ai-generate?prompt=A+minimalist+logo+for+a+interior+design+company+called+Skylight+Furnishings.++The+logo+being+%22The+sky%27s+the+limit%21%22&style=noStyle (Accessed: 27 March 2024).

4) bas123 (2013) Interior design image collection. Available at:

        Image 1 https://wallhaven.cc/w/neegjk 

        Image 2 https://wallhaven.cc/w/0qgkwd

        Image 3 https://wallhaven.cc/w/nkkem7

        Image 4https://wallhaven.cc/w/0jkp6q 

        Retrieved from: Wallhaven (Accessed: 27 March 2024).

5) Pierce, J. (2024) SPRING DECORATING IDEAS || BUDGET-FRIENDLY DECOR TIPS || DECORATING FOR SPRING. Available at: https://www.youtube.com/watch?v=PtKsH1oAW7I (Accessed: 27 March 2024).

6) McGowan, K. (2023) 10 INTERIOR DESIGN STYLING SECRETS YOU SHOULD KNOW | DESIGN HACKS. Available at: https://www.youtube.com/watch?v=jH4JU7Ihaa8 (Accessed: 27 March 2024).