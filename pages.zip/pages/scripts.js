const theDate = new Date();
document.write("&copy; " + 
    theDate.getFullYear())
document.write(" Amadou Sow | Last modified: ")
const modifiedDate = new Date(document.lastModified)
document.write(modifiedDate.toDateString())


function validateForm (){
    //check that someone atually entered something 
    const validateName = document.getElementById("name").value;
    if (validateName == "Your name here" || validateName == "" ){
        alert("Please enter your name")
    }
    //check the email address is valid
    const validateEmail = document.getElementById("email").value;
    if(validateEmail.includes("@") && validateEmail.includes(".")) {}
    else{
        alert("Not a valid email format!")
    }
}
